#!/bin/bash

g++ -o main.exe main.c .\data\*.c .\brain\*.c .\interface\*.c
.\main.exe

