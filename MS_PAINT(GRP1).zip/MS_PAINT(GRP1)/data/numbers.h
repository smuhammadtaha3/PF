void print_number_range(char symbol, char color, int x, int y, int size, char start, char end);
void print_all_number(char symbol, char color, int x, int y, int size);

// for numbers :-
void number_0(int x, int y, int size, char symbol); // Declerationn For "0"
void number_1(int x, int y, int size, char symbol); // Declerationn For "1"
void number_2(int x, int y, int size, char symbol); // Declerationn For "2"
void number_3(int x, int y, int size, char symbol); // Declerationn For "3"
void number_4(int x, int y, int size, char symbol); // Declerationn For "4"
void number_5(int x, int y, int size, char symbol); // Declerationn For "5"
void number_6(int x, int y, int size, char symbol); // Declerationn For "6"
void number_7(int x, int y, int size, char symbol); // Declerationn For "7"
void number_8(int x, int y, int size, char symbol); // Declerationn For "8"
void number_9(int x, int y, int size, char symbol); // Declerationn For "9"