void printSymbol(int x, int y, char color,char symbol);
void free_hand_drawings(char symbol);