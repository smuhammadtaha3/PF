#ifndef DATA_HEADER_FILE
#define DATA_HEADER_FIE

#include "shapes.h"
#include "free_hand_drawing.h"
#include "alphabets.h"
#include "numbers.h"
#include "color.h"
#include "positions.h"
#include "filestructures.h"

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <windows.h>



extern FILE *fptr;
extern FILE *fptr2;
extern FILE *exist;


#endif