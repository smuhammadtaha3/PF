void gotoxy(int x, int y);
void inputs_pos(int p, int q);