#define RED 4
#define BLUE 1
#define GREEN 2
#define YELLOW 6
#define WHITE 7

void set_color(char color);
void reset_color();